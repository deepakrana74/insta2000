<?php

    namespace app\controllers;

    use Yii;
    use yii\web\Controller;

    class AdminController extends Controller{

        public function actionIndex(){

            
        }   
    }